#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from typing import List, Dict
import logging
import kserve
import http.client
import json
import numpy as np
#import pandas as pd
import datetime

UNKNOWN_TOKEN = 'UNK'
#raw data columns
RAW_COLUMN_NAME = ['timestamp', 'Current_Phase_Average', 'Weather_Temperature_Celsius', 'Weather_Relative_Humidity',\
        'Global_Horizontal_Radiation', 'Diffuse_Horizontal_Radiation', 'Wind_Direction', 'Weather_Daily_Rainfall']

def preprocess(inputs: Dict, data_path: str):
    """Pre-process activity of the driver input data.

    Args:
        inputs (Dict): http request

    Returns:
        Dict: Returns the request input after ingesting online features
    """
    result_data = {'instances': []}
    input_data = inputs['instances']
    fea_type_file = os.path.join(data_path, 'feature_type.txt')
    fea_value_file = os.path.join(data_path, 'feature_value.txt')
    if not os.path.isfile(fea_type_file) or not os.path.isfile(fea_value_file):
        logging.info("missing file, %s or %s", fea_type_file, fea_value_file)
        return result_data
    fea_type = load_feature_type(fea_type_file)
    fea_value = load_feature_value(fea_value_file)
    #print(fea_type)
    #print(fea_value)
    for data in input_data:
        res = feature_work(data, RAW_COLUMN_NAME, fea_type, fea_value)
        if res:
            result_data['instances'].append(res)
    #logging.info("The input for model predict is %s", result_data)
    return result_data

def feature_work(raw_data: List, cols_name: List, type_info: List, value_info: Dict):
    res = []
    md = {}
    for n,v in zip(cols_name, raw_data):
        md[n] = v
    # 特征抽取
    if 'timestamp' in md:
        ts = md['timestamp']
        #date_info = pd.to_datetime(ts)
        date_info = datetime.datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
        md['Month'] = date_info.month
        md['Day'] = date_info.day
        #md['Day_Of_Week'] = date_info.dayofweek
        md['Day_Of_Week'] = date_info.weekday
        md['Hour'] = date_info.hour
    else:
        md['Month'] = UNKNOWN_TOKEN
        md['Day'] = UNKNOWN_TOKEN
        md['Day_Of_Week'] = UNKNOWN_TOKEN
        md['Hour'] = UNKNOWN_TOKEN
    # 特征变换
    for f,t in type_info:
        values = value_info[f]
        if t == 'category':
            if f in md and md[f] and str(md[f]) in values:
                res.append(values[str(md[f])])
            else:
                res.append(values[UNKNOWN_TOKEN])
        elif t == 'numeric':
            mean = float(values['mean'])
            std = float(values['std'])
            if f in md and f in ['Weather_Temperature_Celsius', 'Weather_Relative_Humidity', \
                    'Global_Horizontal_Radiation', 'Diffuse_Horizontal_Radiation']: # 标准化
                if std > 0:
                    res.append((float(md[f])-mean)/std)
                else:
                    res.append(float(md[f]))
            elif f in md: # 使用原数值
                res.append(float(md[f]))
            else: # 缺失值使用均值填充
                res.append(mean)
    return res

def load_feature_value(feature_value_file: str):
    """
    features_value_file: 特征统计信息
    返回字典:
    {
        feature1: {min:0, max:0, mean:0, std:0},
        feature2: {v1:0, v2:1}
    }
    """
    fea_info = {}
    with open(feature_value_file, 'r') as file1:
        for line in file1:
            # name type values
            vs = line.strip('\r\n').split('\t')
            dv = json.loads(vs[2])
            if vs[1] == 'category':
                if ('values' in dv) and dv['values'] and type(dv['values']) == list:
                    md = {}
                    for i,v in enumerate(dv['values']):
                        if not v in md:
                            md[v] = i
                    fea_info[vs[0]] = md
                elif 'from_file' in dv and dv['from_file'] and type(dv['from_file']) == 'str':
                    md = load_category_values(dv['from_file'])
                    fea_info[vs[0]] = md
            elif vs[1] == 'numeric' and dv: # dv is a dict {mean:0, std:0,...}
                fea_info[vs[0]] = dv
    return fea_info

def load_feature_type(feature_list_file: str):
    """
    feature_list_file: 特征序列
    返回二维数组[[feature, type]]
    """
    fea_type = []
    with open(feature_list_file, 'r') as file1:
        for line in file1:
            # name type
            vs = line.strip('\r\n').split('\t')
            fea_type.append((vs[0], vs[1]))
    return fea_type

def postprocess(inputs: Dict, data_path: str) -> Dict:
    logging.info("The output from model predict is %s", inputs)
    '''
    if self.protocol == "grpc-v2":
        response = InferResult(inputs)
        return response.get_response(as_json=True)
    elif self.protocol == "http":
        pass
    '''
    return inputs
